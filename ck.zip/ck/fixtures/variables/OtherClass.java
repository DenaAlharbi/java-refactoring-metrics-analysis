package variables;

class OtherClass {
	
}